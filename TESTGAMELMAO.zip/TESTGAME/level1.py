import pygame
from tp import pole
from tile import GTile, Tile, tele, endport
from levellayout import tilesize, swid
from player import Player, enemies
from endpo import endport
class Level:
	def __init__(self,level_data,surface):
		self.world_shift = 0
		self.bullshift = 9
		self.display_surface = surface
		self.levelsetup(level_data)
		self.end = False
		self.gameoverstat = False
		self.bulletfired = False
		self.normal = pygame.sprite.Group()
	def levelsetup(self,layout):
		global x 
		global y
		self.tiles = pygame.sprite.Group()
		self.player = pygame.sprite.GroupSingle()
		self.tele1 = pygame.sprite.Group()
		self.endportal = pygame.sprite.Group()
		self.deathtiles = pygame.sprite.Group()
		self.enemy = pygame.sprite.Group()
		self.bullets = pygame.sprite.Group()
		self.bg = pygame.sprite.Group()
		for row_index,row in enumerate(layout):
			for col_index,column in enumerate(row):
				x = col_index * tilesize
				y = row_index * tilesize
				if column =='X':
					tile = Tile((x,y),tilesize)
					self.tiles.add(tile)
				if column == 'L':
					telep = tele((x,y),tilesize)
					self.tele1.add(telep)	
				if column == 'P':
					playerspr = Player((x,y))
					self.player.add(playerspr)

				if column == 'Q':
				
				    endporta = endport((x,y),tilesize)
				    self.endportal.add(endporta)
				if column =='J':
					dtile = GTile((x,y),tilesize)
					self.deathtiles.add(dtile)
				if column == 'E':
					enem = enemies((x,y))
					self.enemy.add(enem)
				if column == 'I':
					pole1 = pole((x,y))
					self.bg.add(pole1)
	def reset(self):
		self.levelsetup(level_data)		    	
	def scroll_x(self):
		player = self.player.sprite
		bullet = self.bullets.sprites
		player_x = player.rect.centerx
		movx = player.movement.x 

		if player_x < swid/2.5 and movx < 0  :
			self.world_shift = 10
			player.sp = 0
		elif player_x > swid - (swid/2.5) and movx > 0:
			self.world_shift= -10
			player.sp = 0
		else:
			self.world_shift = 0
			player.sp = 8
		for sprite in self.bullets.sprites():
			if player_x < swid/2.5 and movx < 0:
				if sprite.direction < 0:
					self.bullshift = 0
				if sprite.direction > 0:
					self.bullshift = 10
			elif player_x > swid - (swid/2.5) and movx > 0:
				if sprite.direction < 0:
					self.bullshift = -10
				if sprite.direction > 0:
					self.bullshift = 0		
			else:
				self.bullshift = 0			



	def move(self):	
		player = self.player.sprite 
		hit = {"top": False, "bottom": False, "left": False, "right": False}
		player.rect.x += player.movement.x*player.sp
		test_rect = player.rect.copy()
		verified_collisions = []
		for sprite in self.tiles.sprites():
			if test_rect.colliderect(sprite):
				verified_collisions.append(sprite)
        
		for sprite in verified_collisions:
			if player.movement.x > 0:
				test_rect.right = sprite.rect.left
				player.rect.x = test_rect.x 
				hit["right"] = True
			if player.movement.x < 0:
				test_rect.left = sprite.rect.right
				player.rect.x = test_rect.x 
				hit["left"] = True
				player.rect.x

		player.grav()	

		test_rect = player.rect.copy()
		verified_collisions = []
		for sprite in self.tiles.sprites():
			if test_rect.colliderect(sprite):
				verified_collisions.append(sprite)
		for sprite in verified_collisions:
			if player.movement.y > 0:
				test_rect.bottom = sprite.rect.top
				player.rect.y = test_rect.y
				hit["top"] = True
			if player.movement.y < 0:
				test_rect.top = sprite.rect.bottom
				player.rect.y = test_rect.y
			hit["bottom"] = True

		if hit["bottom"]:
			player.movement.y = 0
			player.ground = True	
		return hit

		
	def check(self):
		player = self.player.sprite
		if player.movement.y > 0:
			player.ground = False
		
	def tpcol(self):
		player = self.player.sprite
		for sprite in self.tele1.sprites():
			if sprite.rect.colliderect(player.rect2):
				if player.level < 3 :
					player.level += 1
				else:
					player.movement.y = -10

	
	def deathcol(self):

		player = self.player.sprite
		for sprite in self.deathtiles.sprites():
			if sprite.rect.colliderect(player.rect):
				self.gameoverstat = True

	def enemcol(self):
		player = self.player.sprite
		for sprite in self.enemy.sprites():
			if sprite.rect.colliderect(player.rect2):
				self.gameoverstat = True
				
	def endportcol(self):
		global x 
		global y
		fontlmao = pygame.font.SysFont('Comic Sans',50)
		player = self.player.sprite
		for sprite in self.endportal.sprites():
			if sprite.rect.colliderect(player.rect):
				if player.level==3:
					player.level += 1
				else:
					joe = fontlmao.render('You must go thru all the portals',1,'white')
					self.display_surface.blit(joe,(200,2))
	

				


				
	def bulletcheck(self):
		player = self.player.sprite
		bullet = self.bullets
		enemies = self.enemy
		tile = self.tiles
		hits2 = pygame.sprite.groupcollide(tile,bullet,False,True)
		hits = pygame.sprite.groupcollide(enemies,bullet,True,True)
		if hits:
			player.score +=100
		for sprite in self.bullets.sprites():
			if sprite.rect.x > 1000:
				sprite.kill()
			if sprite.rect.x < 0:
				sprite.kill()		




	def run(self):
		#tiles 
		self.scroll_x()
		self.bg.draw(self.display_surface)
		self.bg.update(self.world_shift*0.25)
		self.tiles.update(self.world_shift)
		self.tele1.update(self.world_shift)
		self.endportal.update(self.world_shift)
		self.deathtiles.update(self.world_shift)
		self.enemy.update(self.world_shift)
		self.tele1.draw(self.display_surface)
		self.tiles.draw(self.display_surface)
		self.endportal.draw(self.display_surface)
		self.deathtiles.draw(self.display_surface)
		self.bullets.draw(self.display_surface)
		self.bullets.update(self.bullshift)
		#collisons
		self.move()
		self.deathcol()
		self.tpcol()
		self.endportcol()
		self.enemcol()
		# entities
		self.player.draw(self.display_surface)
		self.player.update()
		self.enemy.draw(self.display_surface)
		#normal sprites
		self.normal.draw(self.display_surface)
		self.normal.update()
		self.bulletcheck()
