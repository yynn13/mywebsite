import pygame

class Player(pygame.sprite.Sprite):
	def __init__(self,pos):
		super().__init__()
		global left 
		global right
		global tlevel 
		self.score = 0
		self.level = 1 
		self.left = False 
		self.right = False
		self.image = pygame.image.load("player.png")
		self.rect = self.image.get_rect(topleft = pos)
		self.movement = pygame.math.Vector2(0,0)
		self.sp = 0
		self.gravity = 1
		self.jumpsp = -10
		self.ground = True
		self.colstat = False
		self.movestat = True
		self.rect2 =  pygame.rect.Rect((self.rect.midbottom), (20, 70))
		self.rect2.midbottom = self.rect.midbottom

	def move(self):
		global left 
		global right
		key = pygame.key.get_pressed()
		if (key[pygame.K_UP] or key[pygame.K_SPACE]) and self.jumpsp > -15:
			if self.ground == True:
				self.jump()

		elif key[pygame.K_LEFT] or key[pygame.K_a]:
			self.left = True
			self.right = False
			self.movement.x	= -1
			self.rect2.midbottom = self.rect.midbottom
			
				
		elif key[pygame.K_RIGHT] or key[pygame.K_d]:
			self.right = True
			self.left = False
			self.movement.x = 1	 
			self.rect2.midbottom = self.rect.midbottom
		else:
			self.movement.x = 0	
			self.rect2.midbottom = self.rect.midbottom


		if (key[pygame.K_UP] or key[pygame.K_SPACE]) == False:
			self.jumpsp = -10
			self.ground = False

		if self.left == True:
			self.image = pygame.image.load("player2.png")
		if self.right == True:
			self.image = pygame.image.load("player.png")

	
	def grav(self):
		self.movement.y	+= self.gravity
		self.rect.y += self.movement.y
		self.rect2.midbottom = self.rect.midbottom	
	def jump(self):
		if self.jumpsp > -15:
			self.jumpsp -= 0.5

		self.movement.y = self.jumpsp
		self.rect2.midbottom = self.rect.midbottom	
	def bullcreate(self,direction):
		return Bullet(self.rect.x,self.rect.y+50,direction)							
	def update(self):
		self.move()

class Bullet(pygame.sprite.Sprite):
	def __init__(self,posx,posy,direction):
		super().__init__()
		self.image= pygame.Surface((30,10))
		self.image.fill('red')
		self.sp = 10
		self.rect = self.image.get_rect(center = (posx,posy))
		self.direction = direction 					
	def update(self,x_shift):
		self.rect.x += (self.sp	*self.direction	+ x_shift)
		
class enemies(pygame.sprite.Sprite):
	def __init__(self,pos):
		super().__init__()
		self.image = pygame.Surface((35,92))
		self.image.fill('violet')
		self.rect = self.image.get_rect(topleft = pos)
		self.movement = pygame.math.Vector2(0,0)
		self.sp = 0
		self.gravity = 0.8
		self.jumpsp = -10
		self.walkcount = 0

	def update(self,x_shift):
		if self.walkcount < 50:

			self.rect.x += 10
			self.walkcount += 2	
		self.rect.x += x_shift